<?php 
	$db_con = mysqli_connect('localhost', 'root', '', 'dbmetacognitive') or die('koneksi gagal');
?>